from flask import Flask, request, jsonify, render_template
import  speech_recognition as sr

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route('/speech-to-text', methods=['GET', 'POST'])
def speech_to_text():
    r=sr.Recognizer()

    with sr.Microphone() as src:
        audio=r.listen(src)

        t=r.recognize_google(audio,language='ar-AR')
        return t


if __name__ == '__main__':
   app.debug = True
   app.run()
